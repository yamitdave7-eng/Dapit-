'use client';

import React from 'react';
import { Sparkles, Coffee, Calendar, Briefcase, CheckCircle2, ArrowRight } from 'lucide-react';
import { ActiveTab, UserRole } from '@/types';

interface HeroSectionProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenCreate: (type: 'business' | 'event' | 'job' | 'post' | 'talent') => void;
  onSelectBusinessById: (id: string) => void;
  userRole?: UserRole;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  searchQuery,
  setSearchQuery,
  setActiveTab,
  onSelectBusinessById,
  userRole = 'student',
}) => {
  const greetingName =
    userRole === 'business_owner'
      ? 'Elena'
      : userRole === 'student'
      ? 'Marcus'
      : 'Sarah';

  return (
    <div className="mb-6">
      {/* Warm Cozy Welcoming Card (LinkedIn + Apple Aesthetic) */}
      <div className="bg-white dark:bg-[#20262e] rounded-2xl border border-[#e8e6df] dark:border-[#2e3742] p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950 text-[#057642] dark:text-emerald-300 text-[11px] font-bold border border-emerald-200/80 dark:border-emerald-800/60">
              <Sparkles className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
              <span>DAPIT Community & Career Hub</span>
            </div>

            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
              Welcome back, {greetingName}! 👋
            </h1>

            <p className="text-xs sm:text-[13px] text-slate-600 dark:text-slate-300 max-w-xl leading-relaxed">
              Discover local neighborhood businesses, RSVP to upcoming community workshops, and apply for student jobs and internships.
            </p>
          </div>

          {/* Quick Flow CTA */}
          <div className="flex items-center space-x-2 shrink-0">
            <button
              onClick={() => onSelectBusinessById('biz-1')}
              className="px-3.5 py-2 rounded-xl text-xs font-bold text-[#057642] dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 border border-emerald-200 dark:border-emerald-800 transition-colors flex items-center space-x-1.5"
            >
              <span>See Café Spotlight</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* 4-Step Cozy Mini-Workflow: How LocalLens & CareerLink Connect */}
        <div className="mt-4 pt-4 border-t border-[#f0eee6] dark:border-[#2e3742] grid grid-cols-2 lg:grid-cols-4 gap-2.5">
          <div
            onClick={() => setActiveTab('businesses')}
            className="p-2.5 rounded-xl bg-[#f8f7f4] dark:bg-slate-800/60 hover:bg-emerald-50/60 dark:hover:bg-slate-800 border border-[#e8e6df] dark:border-[#2e3742] cursor-pointer transition-colors group"
          >
            <div className="flex items-center space-x-1.5 text-xs font-bold text-slate-800 dark:text-white">
              <Coffee className="w-3.5 h-3.5 text-amber-600" />
              <span>1. Café Registers</span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-1">
              Lists menu & shop on LocalLens
            </p>
          </div>

          <div
            onClick={() => setActiveTab('events')}
            className="p-2.5 rounded-xl bg-[#f8f7f4] dark:bg-slate-800/60 hover:bg-emerald-50/60 dark:hover:bg-slate-800 border border-[#e8e6df] dark:border-[#2e3742] cursor-pointer transition-colors group"
          >
            <div className="flex items-center space-x-1.5 text-xs font-bold text-slate-800 dark:text-white">
              <Calendar className="w-3.5 h-3.5 text-teal-600" />
              <span>2. Hosts Workshop</span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-1">
              Latte Art & Coffee Tasting
            </p>
          </div>

          <div
            onClick={() => setActiveTab('jobs')}
            className="p-2.5 rounded-xl bg-[#f8f7f4] dark:bg-slate-800/60 hover:bg-emerald-50/60 dark:hover:bg-slate-800 border border-[#e8e6df] dark:border-[#2e3742] cursor-pointer transition-colors group"
          >
            <div className="flex items-center space-x-1.5 text-xs font-bold text-slate-800 dark:text-white">
              <Briefcase className="w-3.5 h-3.5 text-emerald-600" />
              <span>3. Hires Student</span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-1">
              Weekend Barista vacancy
            </p>
          </div>

          <div
            onClick={() => setActiveTab('jobs')}
            className="p-2.5 rounded-xl bg-[#f8f7f4] dark:bg-slate-800/60 hover:bg-emerald-50/60 dark:hover:bg-slate-800 border border-[#e8e6df] dark:border-[#2e3742] cursor-pointer transition-colors group"
          >
            <div className="flex items-center space-x-1.5 text-xs font-bold text-slate-800 dark:text-white">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>4. Easy Apply</span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-1">
              1-click resume submission
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
